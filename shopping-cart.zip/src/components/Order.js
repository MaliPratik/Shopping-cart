import React from 'react'

function Order() {
  return (
    <div className='col-lg-12'>
        <div className='App mt-5 p-5 bg-white'>
            <h2 className='mt-5 p-5 border fw-bold shadow'>Thank You</h2>
            <h4 className='mt-5 p-5 text-success border fw-bold shadow'>Successful Your Order</h4>
            <p className='mt-5 '>Reciving your Order after 5 to 6 days</p>
        </div>
    </div>
  )
}

export default Order;
